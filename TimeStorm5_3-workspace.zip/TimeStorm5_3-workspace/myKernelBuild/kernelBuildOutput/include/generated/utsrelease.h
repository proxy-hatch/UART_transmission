#define UTS_RELEASE "4.4.0-ts-armv7l-xilinx"
