/* This file is auto generated, version 1 */
/* SMP PREEMPT */
#define UTS_MACHINE "arm"
#define UTS_VERSION "#1 SMP PREEMPT Wed Nov 22 16:49:44 PST 2017"
#define LINUX_COMPILE_BY "osboxes"
#define LINUX_COMPILE_HOST "osboxes"
#define LINUX_COMPILER "gcc version 4.9.3 (Timesys 20160620) "
